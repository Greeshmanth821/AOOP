package Com.StudentInformation;

public interface enroll {
 void enrolls(student student, course course);
}
