package Com.Music_Streaming;

public interface Music_Streaming {
	void playMusic();
    void stopMusic();
}
