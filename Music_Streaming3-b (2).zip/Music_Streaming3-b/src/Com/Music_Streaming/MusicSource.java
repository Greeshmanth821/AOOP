package Com.Music_Streaming;

public interface MusicSource {
	void play();
    void stop();
}




