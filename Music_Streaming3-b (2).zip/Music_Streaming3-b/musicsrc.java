package com.music;

public interface musicsrc {
void play();

}
