package Com.Auction_System;

public interface observer {
 void update(String event);
 
}
