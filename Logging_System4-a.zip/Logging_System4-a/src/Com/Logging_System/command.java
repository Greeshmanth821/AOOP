package Com.Logging_System;

public interface command {
 void exe(String message);
}
