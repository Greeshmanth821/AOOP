package Com.Logging_System;

public enum loglevel {
INFO,DEBUG,ERROR
}
